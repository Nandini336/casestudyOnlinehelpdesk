﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
namespace ProjectNew
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;
        string txtGender;
        SqlCommand cmdForUserName;
        SqlConnection cn2;
        string queryForUserID;
        SqlCommand cmdForUserID;
        SqlConnection conUserID;
        SqlDataReader drForUserID;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txtFname_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtLname_TextChanged(object sender, EventArgs e)
        {

        }

        protected void rbtMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void rbtFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void txtUname_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtRpswd_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddlDept_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtSem_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtAdd_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtMob_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ddlDays_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void txtYear_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click1(object sender, EventArgs e)
        {
            if (rbtAccept.Checked.ToString() == "True")
            {
                cn2 = new SqlConnection(ConfigurationManager.ConnectionStrings["OHDConn"].ConnectionString);
                cn2.Open();
                string queryForUserName = "Select USERNAME from register where USERNAME= '" + txtUname.Text.Trim() + "' ";

                cmdForUserName = new SqlCommand(queryForUserName, cn2);
                dr = cmdForUserName.ExecuteReader(CommandBehavior.CloseConnection);
                int res = 0;
                if (dr.HasRows)
                {
                    Response.Write("<script>alert('Username you have entered already exists.Please enter another username!')</script>");
                }
                else
                {


                    if (rbtMale.Checked == true)
                    {
                        txtGender = "Male";
                    }
                    else if (rbtFemale.Checked == true)
                    {
                        txtGender = "Female";
                    }


                    cn = new SqlConnection(ConfigurationManager.ConnectionStrings["OHDConn"].ConnectionString);
                    cn.Open();
                    SqlCommand cmd = new SqlCommand("spregister", cn);
                    cmd.CommandType = CommandType.StoredProcedure;


                    cmd.Parameters.AddWithValue("@Firstname", txtFname.Text.Trim());
                    cmd.Parameters.AddWithValue("@LASTNAME", txtLname.Text.Trim());
                    cmd.Parameters.AddWithValue("@USERNAME", txtUname.Text.Trim());
                    cmd.Parameters.AddWithValue("@PASSWORD", txtPassword.Text.Trim());
                    cmd.Parameters.AddWithValue("@RETYPE_PASSWORD", txtRpswd.Text.Trim());
                    cmd.Parameters.AddWithValue("@EMAIL_ADDRESS", txtEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@Department", ddlDept.SelectedValue);
                    cmd.Parameters.AddWithValue("@SEMSTER", txtSem.Text.Trim());
                    cmd.Parameters.AddWithValue("@ADDRESS", txtAdd.Text.Trim());
                    cmd.Parameters.AddWithValue("@MOBILE_NO", txtMob.Text.Trim());
                    cmd.Parameters.AddWithValue("@GENDER", txtGender);

                    //registerCmdObj.Parameters.AddWithValue("@result int out

                    //output parameters are expected in the procedure
                    //1. Create an object of SqlParameter class with the same parameter name
                    SqlParameter resParameter = new SqlParameter("@result", SqlDbType.Int);

                    //2. Set the direction of the parameter object created in step 1
                    resParameter.Direction = ParameterDirection.Output;

                    //3. add the above parameter object into the Parameters Collection of the Command Object
                    cmd.Parameters.Add(resParameter);

                    cmd.ExecuteNonQuery();
                    res = (int)resParameter.Value;
                    //res = Convert.ToInt32(resParameter.Value);
                    conUserID = new SqlConnection(ConfigurationManager.ConnectionStrings["OHDConn"].ConnectionString);
                    conUserID.Open();
                    queryForUserID = "Select userID from register where USERNAME= '" + txtUname.Text.Trim() + "' ";

                    cmdForUserID = new SqlCommand(queryForUserID, conUserID);
                    drForUserID = cmdForUserID.ExecuteReader(CommandBehavior.CloseConnection);


                    while (drForUserID.Read())
                    {
                        string userIdFetch = drForUserID["userID"].ToString();
                        Session["uID"] = userIdFetch;

                    }




                    Response.Write("<script>alert('You have successfully created your account!')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('You have chosen not to register!')</script>");
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {


            Response.Write("<script>alert('You have chosen not to register!')</script>");

        }

        protected void rbtAccept_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void rbtNotAccept_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void rbtFemale_CheckedChanged1(object sender, EventArgs e)
        {

        }
    }
}
