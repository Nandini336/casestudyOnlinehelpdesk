﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace ProjectNew
{
    public partial class WebForm13 : System.Web.UI.Page
    {
        SqlConnection cn;
        SqlCommand cmd;
        SqlConnection cnWelcm;
        SqlCommand cmdWelcm;
        SqlDataReader drWelcm;
        string Firstname;
        string Lastname;
        protected void Page_Load(object sender, EventArgs e)
        {
            string user_n = Session["USERNAME"].ToString();
            cnWelcm = new SqlConnection(ConfigurationManager.ConnectionStrings["OHDConn"].ConnectionString);
            cnWelcm.Open();

            string welcmUser = "select FIRSTNAME,LASTNAME from adminLogin where USERNAME='" + user_n + "'";
            cmdWelcm = new SqlCommand(welcmUser, cnWelcm);
            cmdWelcm.ExecuteNonQuery();
            drWelcm = cmdWelcm.ExecuteReader();
            while (drWelcm.Read())
            {
                Firstname = drWelcm["FIRSTNAME"].ToString();
                Lastname = drWelcm["LASTNAME"].ToString();

            }
            lblWelcome.Text = "Welcome   " + Firstname + "&nbsp" + "&nbsp" + Lastname + "<br>";
            lblLtime.Text = " Your Login Date and Time Is:" + "&nbsp" + "&nbsp" + System.DateTime.Now;
        }
    }
}