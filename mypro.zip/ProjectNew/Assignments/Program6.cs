﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the principle Amount : ");
            int principle = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the rate of interest : ");
            double interest = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter the time in years : ");
            double time = Convert.ToDouble(Console.ReadLine());
            double amount = 0;
            amount = principle * Math.Pow((1 + (interest * 0.01) / time), time);
            Console.WriteLine($"compound amount " + amount);
            double fixeddeposit = amount - principle;
            Console.WriteLine($"Fixed deposit " + fixeddeposit);
            Console.ReadLine();

        }
    }
}
