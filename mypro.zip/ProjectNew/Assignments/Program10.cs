﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise10
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr1 = new int[10, 10];
            Console.WriteLine("pascal triangle");
            for (int row = 0; row < 10; row++)
            {
                for (int sp = 10; sp < row; sp--)
                {
                    Console.Write(" ");
                }
                for (int column = 0; column <= row; column++)
                {
                    if (row == column || column == 0)
                    {
                        arr1[row, column] = 1;
                    }
                    else
                    {
                        arr1[row, column] = arr1[row - 1, column] + arr1[row - 1, column - 1];
                    }
                    Console.Write(arr1[row, column]);

                }
                Console.ReadLine();
            }
        }

    }
}

