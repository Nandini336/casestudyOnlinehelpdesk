﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise4
{
    class Program
    {
        
            static void Main(string[] args)
        {
                int Fib1 = 0;
                int Fib2 = 1;

                Console.WriteLine(Fib1);
                Console.WriteLine(Fib2);
                for (int i = 0; i < 8; i++)
                {
                    int Fib3 = Fib1 + Fib2;
                    Console.WriteLine(Fib3);
                    Fib1 = Fib2;
                    Fib2 = Fib3;
                }
                Console.ReadLine();

            }
        }
}
