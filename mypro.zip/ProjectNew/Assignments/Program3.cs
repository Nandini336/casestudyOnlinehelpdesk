﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, rem = 0, sum = 0;
            Console.WriteLine("Enter a Number : ");
            num = int.Parse(Console.ReadLine());
            while (num != 0)
            {
                rem = num % 10;
                sum = sum + rem;
                num = num / 10;

            }
            Console.WriteLine("sum of Entered Number is : " + sum);
            Console.ReadLine();

        }
    }
}
