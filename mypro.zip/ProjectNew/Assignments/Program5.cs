﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise5
{
    class Program
    {
        static void Main(string[] args)
        {
            // Write a program that accepts values in US$ and converts each value entered to its Indian Rupees and British Pounds equivalent.
            Console.WriteLine("Enter the US$");
            int Us_dollar = Convert.ToInt32(Console.ReadLine());
            double IndRupees = ConvertRupees(Us_dollar);
            Console.WriteLine(Us_dollar + "$ US dollar equals to Rs." + IndRupees + " Indian rupees");
            double BritishPound = ConvertBritishPound(Us_dollar);
            Console.WriteLine(Us_dollar + "$ US dollar equals to £ " + BritishPound + " British pound");
            Console.ReadLine();
        }
        public static double ConvertRupees(int Us_dollar)
        {
            double IndRupees = 65.48 * Us_dollar;
            return IndRupees;

        }
        public static double ConvertBritishPound(int Us_dollar)
        {
            double BritishPound = 0.81 * Us_dollar;
            return BritishPound;
        }

    }
}

