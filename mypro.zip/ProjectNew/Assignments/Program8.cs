﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a num:");
            int num = Convert.ToInt32(Console.ReadLine());
            Boolean res = IsPrimeNum(num);
            if (res)
                Console.WriteLine("num is prime");
            else
                Console.WriteLine("num is not prime");
            Console.ReadLine();
        }

        static Boolean IsPrimeNum(int num)
        {
            int i = 2;
            while (i <= num / 2)
            {
                if (num % i == 0)
                {
                    return false;
                }
                i++;
            }

            return true;
        }

    }
}

