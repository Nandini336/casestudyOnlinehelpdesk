﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise10
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the given string");
            String s = Console.ReadLine();
            Console.WriteLine(" ENTER THE CHOICE");
            Console.WriteLine(" 1  to check anagram");
            Console.WriteLine(" 2 to check palindrome");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    aNAGRAM(s);
                    break;
                case 2:
                    Palindrome(s);
                    break;
            }
            Console.ReadLine();



        }


        public static string ReverseString(string s)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }
        public static void aNAGRAM(string s)
        {
            char[] char1 = s.ToLower().ToCharArray();
            String a = ReverseString(s);
            char[] char2 = a.ToLower().ToCharArray();
            Array.Sort(char1);
            Array.Sort(char2);
            string NewWord1 = new string(char1);
            string NewWord2 = new string(char2);
            if (NewWord1 == NewWord2)
            {
                Console.WriteLine("Yes! Word \"{0}\"  are Anagrams", s);
            }
            else
            {
                Console.WriteLine("No! Word \"{0}\" are not Anagrams", s);
            }
        }
        public static void Palindrome(String s)
        {
            String a = ReverseString(s);
            if (string.Compare(s, a) == 0)
            {
                Console.WriteLine(" word is palindrome ");
            }
            else
            {
                Console.WriteLine(" word is  not palindrome ");
            }
        }
    }
}
