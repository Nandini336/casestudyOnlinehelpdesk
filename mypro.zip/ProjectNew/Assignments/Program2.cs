﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
       
            static void Main(string[] args)
        {
                Console.WriteLine("Enter range");
                int fact;
                int n = Convert.ToInt32(Console.ReadLine());
                int j;

                while (n > 0)
                {
                    fact = 1;
                    for (j = n; j > 0; j--)
                    {
                        fact = fact * j;
                    }
                    Console.WriteLine("factorial of {0},{1}", n, fact);
                    n--;
                }
                Console.ReadLine();


            }

        }
    }

